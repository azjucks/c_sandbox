#include <stdlib.h>

#include "float.h"
#include "my_put_char.h"


int main()
{
	t_float f;

	init_from_string(&f, "-1,234");

//	print_float(&f);

	reset_float(&f);

/*	my_put_char('\n');

	add_digit_right(&f, 4);

	print_float(&f);

	my_put_char('\n');

	add_digit_left(&f, 3);

	print_float(&f);
*/
	return 0;
}
