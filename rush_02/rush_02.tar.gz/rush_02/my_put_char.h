#ifndef __MY_PUT_CHAR__
#define __MY_PUT_CHAR__

void my_put_char(char c);

#endif
