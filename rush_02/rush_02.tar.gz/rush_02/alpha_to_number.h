#ifndef __ALPHA_TO_NUMBER__
#define __ALPHA_TO_NUMBER__

int alpha_to_number(char const* str);

#endif
