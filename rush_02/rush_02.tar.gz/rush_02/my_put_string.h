#ifndef __MY_PUT_STRING__
#define __MY_PUT_STRING__

void my_put_string(char const* str);

#endif
