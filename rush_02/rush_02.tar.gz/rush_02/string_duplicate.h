#ifndef __STRING_DUUPLICATE__
#define __STRING_DUPLICATE__

char* string_duplicate(char const* str);

#endif
