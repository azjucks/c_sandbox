#include <stdlib.h>
#include <stdio.h>

#include "float.h"
#include "my_put_string.h"
#include "my_put_char.h"
#include "my_put_number.h"
#include "string_length.h"
#include "alpha_to_number.h"


int	is_negative(int* n)
{
	if(*n < 0)
	{
		*n = -*n;
		return 1;
	}
	else
	{
		return 0;
	}
}


void	init_float(t_float* f)
{
	if (f == NULL)
		return;

	f = (t_float*) malloc(sizeof(t_float));
	if (f == NULL)
		return;

	f->mantissa = NULL;
	f->exponent = 0;
}


void	reset_float(t_float* f)
{
	if (f == NULL)
		return;

	if (f->mantissa != NULL)
		free(f->mantissa);

	f->mantissa = NULL;
	f->exponent = 0;

	free(f);
}


void	duplicate_float(t_float* fdest, t_float const* fsrc)
{
	if (fdest == NULL || fsrc == NULL || fsrc->mantissa == NULL)
		return;

	fdest->mantissa = (int *) malloc((fsrc->mantissa[0] + 1) * sizeof(int));
	if (fdest->mantissa == NULL)
		return;

	fdest->mantissa = fsrc->mantissa;
	fdest->exponent = fsrc->exponent;
}


void	add_digit_right(t_float* f, int digit)
{
	if (digit < 0 || f == NULL)
		return;

	f->mantissa = (int *) realloc(f->mantissa, ++f->mantissa[0] * sizeof(int));
	if (f->mantissa == NULL)
		return;

	f->mantissa[f->mantissa[0]] = digit;
}


void	add_digit_left(t_float* f, int digit)
{
	if (digit < 0 || f == NULL)
		return;

	f->mantissa = (int *) realloc(f->mantissa, ++f->mantissa[0] * sizeof(int));
	if (f->mantissa == NULL)
		return;

	int i = f->mantissa[0];

	for (; i > 0; --i)
	{
		f->mantissa[i] = f->mantissa[i - 1];
	}
	
	f->mantissa[1] = digit;

	if (is_negative(&f->mantissa[2]))
	{
		f->mantissa[1] = -f->mantissa[1];
	}
}


void	init_from_string(t_float* f, char const* str)
{
	if (f == NULL || str == NULL || string_length(str) == 0 || str[0] == ',')
		return;

	init_float(f);

	int size = string_length(str), exp = size, nb_size = size, exponent = 0;

	for (; exp >= 0; --exp)
	{
		++exponent;
		if (str[exp] == ',')
		{
			--nb_size;
			break;
		}
	}

	if (str[0] == '-')
		--nb_size;

	f->mantissa = malloc((nb_size + 1) * sizeof(int));
	if(f->mantissa == NULL)
		return;

	f->mantissa[0] = nb_size;

	my_put_number(f->mantissa[0]);
	fflush(stdout);

	int i = 1;

	for (int j = 0; j < size; ++j)
	{
		if (str[j] >= '0' && str[j] <= '9')
		{
			char temp = str[j];
			int temp_int = alpha_to_number(&temp);
			if (j == 1 && str[0] == '-')
				temp_int = -temp_int;
			f->mantissa[i] = temp_int;
			i++;
		}
	}

	f->exponent = --exponent;
}


void	print_float(t_float const* f)
{
	if (f == NULL)
		return;

	int size = f->mantissa[0], is_negative_var = is_negative(&f->mantissa[1]);

	if(is_negative_var)
		my_put_char('-');

	for (int i = 1; i <= size; ++i)
	{
		if (i == size - f->exponent)
			my_put_char(',');
		my_put_number(f->mantissa[i]);
	}

	my_put_char('\n');

	if (is_negative_var)
		f->mantissa[1] = -f->mantissa[1];
}
