#ifndef __FLOAT__
#define __FLOAT__

struct s_float
{
	int* mantissa;
	int exponent;
};

typedef struct s_float t_float;

int	is_negative(int* n);

void	init_float(t_float* f);

void	reset_float(t_float* f);

void	duplicate_float(t_float* fdest, t_float const* fsrc);

void	add_digit_right(t_float* f, int digit);

void	add_digit_left(t_float* f, int digit);

void	init_from_string(t_float* f, char const* str);

void	print_float(t_float const* f);

#endif
