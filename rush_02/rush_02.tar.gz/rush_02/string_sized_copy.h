#ifndef __STRING_SIZED_COPY__
#define __STRING_SIZED_COPY__

char* string_sized_copy(char* dest, char const* src, unsigned int size_max);

#endif
