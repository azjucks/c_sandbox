#ifndef __STRING_LENGTH__
#define __STRING_LENGTH__

unsigned int string_length(char const* str);

#endif
