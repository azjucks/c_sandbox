#ifndef __MY_PUT_NUMBER__
#define __MY_PUT_NUMBER__

void my_put_number(int num);

#endif
